from .graficos import graficar_seno
